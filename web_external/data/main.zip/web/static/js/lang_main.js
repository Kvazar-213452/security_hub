function lang_change_main(lang) {
    if (lang === "en") {

    } else if (lang === "uk") {

    }
}
