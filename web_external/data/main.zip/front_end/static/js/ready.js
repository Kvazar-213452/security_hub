$(document).ready(function() {
    fetchLogs();
});