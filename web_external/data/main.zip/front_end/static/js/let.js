let visualization_mas = ['visualization1', 'visualization2'];
const unsafeProtocols = ["WEP", "WPA", "HTTP", "FTP", "Telnet", "RDP", "SNMP", "ICMP"];