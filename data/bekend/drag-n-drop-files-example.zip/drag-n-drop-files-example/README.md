# Drag N Drop Files Example

A Pen created on CodePen.io. Original URL: [https://codepen.io/sayeaah/pen/ExxEQKp](https://codepen.io/sayeaah/pen/ExxEQKp).

Drag N Drop Files Example using HTML, CSS and Vanilla JS